var iosappstore = require('app-store-scraper');
var gplaystore = require('google-play-scraper');
var Q = require('q');

var promises = [];
var iosapplist = {};
var androidapplist = {};
var lastiosapplist = {};
var lastandroidapplist = {};

// ===== Configurables =====

var printToConsole = 1; //1 or 0 to toggle console log
var reportChangesOnly = 1; //1 or 0 to toggle change report log
var interval = 60 * 60 * 1000; //query interval in ms

// iTunes App Store Apps
var ios_appid_list = ['ph.telegra.Telegraph', //Telegram
		      'net.whatsapp.WhatsApp', //Whatsapp
		      'com.noapostroph3s.followers.instagram', //Messenger
		      'com.sgiggle.Tango', //Viber
		      'com.viettel.ttnd.mocha', // Line
		      'com.douban.frodo' // Wechat
		     ];

// Google Play Store Apps
var android_appid_list = ['org.telegram.messenger', //Telegram
			  'com.whatsapp', //Whatsapp
			  'com.facebook.orca', //Messenger
			  'com.viber.voip', //Viber
			  'jp.naver.line.android', //Line
			  'com.tencent.mm' //Wechat
			 ];

// Country Codes
country_codes = ['SG', 'MY'];

// ===== End of Configurables =====

// ===== Start of Program =====
executeQuery();
// ===== End of Program =====


// ===== HELPER FUNCTIONS =====
//AppStore Scrape Result Callback
function executeQuery() {
	ios_appid_list.forEach(function(appId){
		country_codes.forEach(function(country_code){
			getiOSAppResult(appId, country_code);
		});
	});

	android_appid_list.forEach(function(appId){
		country_codes.forEach(function(country_code){
			getAndroidAppResult(appId, country_code);
		});
	});
	Q.all(promises).then(function() {
		var sorted_ios = [];
		for(var key in iosapplist) {
		    sorted_ios[sorted_ios.length] = key;
		}
		sorted_ios.sort();
		var sorted_android = [];
		for(var key in androidapplist) {
		    sorted_android[sorted_android.length] = key;
		}
		sorted_android.sort();
		var date = new Date();
		if (printToConsole) {
			if (reportChangesOnly) {
				console.log('<p>========== iOS App List Information @ ' + date + ' =============</p>');
				for (var idx in sorted_ios) {
					var val = iosapplist[sorted_ios[idx]];
					var oldval = lastiosapplist[sorted_ios[idx]];
					if (typeof oldval == 'undefined') {
						console.log('<p>- ' + sorted_ios[idx] + '</p>');
						console.log('<p>        Version: ' + val['version'] + '</p>');
						console.log('<p>        Last Updated: ' + val['updated'] + '</p>');
					} else if (oldval != null && (oldval['version'] != val['version'] || oldval['updated'] != val['updated'])) {
						console.log('<p>- ' + sorted_ios[idx] + '</p>');
						console.log('<p>        Version: ' + oldval['version'] + ' -> ' + val['version'] + '</p>');
						console.log('<p>        Last Updated: ' + oldval['updated'] + ' -> ' + val['updated'] + '</p>');
					}
				};

				console.log('<p>========== Android App List Information @ ' + date + ' =========</p>');
				for (var idx in sorted_android) {
					var val = androidapplist[sorted_android[idx]];
					var oldval = lastandroidapplist[sorted_android[idx]];
					if (typeof oldval == 'undefined') {
						console.log('<p>- ' + sorted_android[idx] + '</p>');
						console.log('<p>        Version: ' + val['version'] + '</p>');
						console.log('<p>        Last Updated: ' + val['updated'] + '</p>');
					} else if (oldval != null && (oldval['version'] != val['version'] || oldval['updated'] != val['updated'])) {
						console.log('<p>- ' + sorted_android[idx] + '</p>');
						console.log('<p>        Version: ' + oldval['version'] + ' -> ' + val['version'] + '</p>');
						console.log('<p>        Last Updated: ' + oldval['updated'] + ' -> ' + val['updated'] + '</p>');
					}
				};
				console.log('');
			} else {
				console.log('<p>========== iOS App List Information @ ' + date + ' =============</p>');
				for (var idx in sorted_ios) {
					var val = iosapplist[sorted_ios[idx]];
					console.log('<p>- ' + sorted_ios[idx] + '</p>');
					console.log('<p>        Version: ' + val['version'] + '</p>');
					console.log('<p>        Last Updated: ' + val['updated'] + '</p>');
				};

				console.log('========== Android App List Information @ ' + date + ' =========</p>');
				for (var idx in sorted_android) {
					var val = androidapplist[sorted_android[idx]];
					console.log('<p>- ' + sorted_android[idx] + '</p>');
					console.log('<p>        Version: ' + val['version'] + '</p>');
					console.log('<p>        Last Updated: ' + val['updated']);
				};
				console.log('');
			}
		}
		lastiosapplist = JSON.parse(JSON.stringify(iosapplist));
		lastandroidapplist = JSON.parse(JSON.stringify(androidapplist));
		setTimeout(function() { executeQuery(); }, interval);
	});
}

//iOS App Store Scraping
function getiOSAppResult(appId, country_code) {
	var app_promise = iosappstore.app({appId: appId, country: country_code}).then(function(result) {
		var result_entry = {};
		result_entry["version"] = result["version"];
		result_entry["updated"] = result["updated"];
		var app_key = appId + '-' + country_code;
		iosapplist[app_key] = result_entry;
	}).catch(console.log);
	promises.push(app_promise);
}

//Android App Store Scraping
function getAndroidAppResult(appId, country_code) {
	var app_promise = gplaystore.app({appId: appId, country: country_code}).then(function(result) {
		var result_entry = {};
		result_entry["version"] = result["version"];
		result_entry["updated"] = result["updated"];
		var app_key = appId + '-' + country_code;
		androidapplist[app_key] = result_entry;
	}, console.log);
	promises.push(app_promise);
}

